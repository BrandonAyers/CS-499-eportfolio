# CS-340-
College project


When writing programs I tend to split my work into sections before I even start coding. I feel like sometimes I want to jump around and code one thing and then switch to another but planning out what I wanna code helps this. The advantages of this is keeping me on task and not making mistakes. This CRUD module can be useful alot of ways in the future by allowing me to have a file to create, read, update, and delete from databases.

The way that I approach a problem is by breaking it down into smaller pieces. When doing the Grazioso Salvare project I would read the requirements 1 part at a time and code that section. In other projects I've made the mistake of reading the entire requirements list and jumping between different sections causing me to lose what I was doing. When creating databases in the future I would continue to look at the requirements and focus on one thing at a time.

Computer Scientist use their skills to program and problem solve software and hardware for others to use. They write code, test code, and evalute sysytems. It matters because without computer scientist we wouldn't be able to do anything that we do on our phones daily. This type of work on the Grazioso would help them doing their work better by providing a more user friendly way of accessing the animal database.
