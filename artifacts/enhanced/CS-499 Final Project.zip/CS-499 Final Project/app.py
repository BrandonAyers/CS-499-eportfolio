from dash import Dash
from models.mongo_model import MongoModel
from views.dashboard_layout import build_layout
from views.dashboard_view import register_callbacks


# Mongo connection string
MONGO_URI = "Redacted due to personal information"


# Create Dash app
app = Dash(__name__)

# Create database model
model = MongoModel(MONGO_URI)

# Pull data once at startup
df = model.read_all()

# Remove Mongo internal id so Dash table doesn’t show it
if '_id' in df.columns:
    df.drop(columns=['_id'], inplace=True)

# Build UI layout
app.layout = build_layout(df)

# Register all callbacks
register_callbacks(app, df, model)


# Run server
if __name__ == "__main__":
    app.run(debug=True, port=8050)
