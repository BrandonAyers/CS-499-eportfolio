from pymongo import MongoClient, TEXT
import pandas as pd


class MongoModel:
    """
    This class handles everything related to MongoDB.
    Basically acts as the middle layer between the app and the database.
    """

    def __init__(self, uri=None, db_name="aac", collection_name="animals"):

        # If no URI is passed in, stop immediately so we don't connect wrong
        if not uri:
            raise ValueError("MongoDB URI not provided")

        # Connect to MongoDB cluster
        self.client = MongoClient(uri)

        # Grab the database and collection we are working with
        self.database = self.client[db_name]
        self.collection = self.database[collection_name]

        # Create indexes when app starts
        # This improves speed when filtering/searching
        self._create_indexes()

    # -------------------------------------------------------
    # INDEX CREATION
    # -------------------------------------------------------
    def _create_indexes(self):
        # These are fields we filter on a lot
        # Indexing keeps lookups fast
        self.collection.create_index("breed")
        self.collection.create_index("age_upon_outcome_in_weeks")
        self.collection.create_index("animal_type")

        # Text index lets us search multiple fields at once
        self.collection.create_index([
            ("name", TEXT),
            ("breed", TEXT),
            ("color", TEXT)
        ])

    # -------------------------------------------------------
    # READ EVERYTHING
    # -------------------------------------------------------
    def read_all(self):
        # Pull entire collection into dataframe
        data = list(self.collection.find({}))
        return pd.DataFrame.from_records(data)

    # -------------------------------------------------------
    # TEXT SEARCH
    # -------------------------------------------------------
    def search_text(self, query):
        # Mongo text search across indexed fields
        results = list(self.collection.find({"$text": {"$search": query}}))
        return pd.DataFrame.from_records(results)

    # -------------------------------------------------------
    # AGGREGATION STATS
    # These run calculations inside MongoDB instead of Python
    # -------------------------------------------------------
    def color_statistics(self):
        pipeline = [
            {"$group": {"_id": "$color", "count": {"$sum": 1}}},
            {"$sort": {"count": -1}},
            {"$limit": 10}
        ]
        return list(self.collection.aggregate(pipeline))

    def breed_statistics(self):
        pipeline = [
            {"$group": {"_id": "$breed", "count": {"$sum": 1}}},
            {"$sort": {"count": -1}},
            {"$limit": 10}
        ]
        return list(self.collection.aggregate(pipeline))

    def average_age(self):
        pipeline = [
            {"$group": {
                "_id": None,
                "avgAge": {"$avg": "$age_upon_outcome_in_weeks"}
            }}
        ]
        result = list(self.collection.aggregate(pipeline))
        return result[0]["avgAge"] if result else 0

    # -------------------------------------------------------
    def close(self):
        # Close connection cleanly
        self.client.close()
